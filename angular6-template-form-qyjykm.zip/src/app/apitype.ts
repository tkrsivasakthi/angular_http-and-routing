export interface Apitype {
  id:any;
  name:any;
  description:any;
subjectId:any;
subjectTypeId:any;
subjectLevelId:any;
subjectOptionId:any;
languageId:any;

}