import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
public courseID:any;
  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    //way 1
// let id= parseInt(this.route.snapshot.paramMap.get('id'));
// this.courseID =id;
//way 2
this.route.paramMap.subscribe(params =>{
  this.courseID=params.get('id');
});
 console.log(this.courseID);
  }

}