import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Apitype} from './Apitype';

@Injectable()
export class ApimiddleService {

  constructor(private http: HttpClient) { }

  searchApi(){
    console.log("calling api");
//typed api call
return this.http.get<Apitype>('https://ibomyangular.azurewebsites.net/api/Courses');
  }

}