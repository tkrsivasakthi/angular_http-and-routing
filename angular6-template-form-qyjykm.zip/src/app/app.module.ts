import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import{Router,RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ViewComponent } from './view/view.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ApimiddleService } from './apimiddle.service';
import { HttpClientModule } from '@angular/common/http';

const myRoots:Routes = [
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent},
  { path: 'register', component: RegisterComponent },
  { path: 'view', component: ViewComponent},
  { path: 'view/:id', component: ViewComponent},
  { path: 'login', component: LoginComponent},
  { path: 'logout', component: LogoutComponent},

  ]


@NgModule({
  imports:      [ BrowserModule, FormsModule,RouterModule.forRoot(myRoots) ,HttpClientModule],
  declarations: [ AppComponent, HelloComponent, RegisterComponent, HomeComponent, ViewComponent, LoginComponent, LogoutComponent ],
  bootstrap:    [ AppComponent ],
  providers: [ApimiddleService]
})
export class AppModule { }
