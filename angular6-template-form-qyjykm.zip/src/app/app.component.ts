import { Component } from '@angular/core';
import { ApimiddleService } from './apimiddle.service';
import {Router} from '@angular/router';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
data :any;
constructor(private apiserv:ApimiddleService,private route:Router){

}
  ngOnInit(){
   console.log("calling ngOnInit");
 this.apiserv.searchApi().subscribe(data=>
      {
        console.log(data);
        this.data=data;
      });
  }

  selectByid(course){
    this.route.navigate(['/view',course.id]);
  }

}
