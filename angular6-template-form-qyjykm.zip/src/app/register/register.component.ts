import { Component, OnInit } from '@angular/core';
import {Newbook} from '../newbook';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
newform:Newbook;

storedb:Newbook[]=[];

  constructor() { }

  ngOnInit() {
  }
  register(newform){
    console.log(newform.bname);
    this.storedb.push(newform);
    console.log(this.storedb);
  }

}