export class Newbook {

constructor(public bname:string,
  public funcname:string,
  public startdate:any,
  public enddate:any,
   public address:string,
  public phone:number,
  public rent:any,
   public advance:number,
  public balance:number,
   public bookername:string
){

}
   
}
